//
//  Materials.m
//  Calculator
//
//  Created by Александр Коровкин on 17.09.13.
//  Copyright (c) 2013 Александр Коровкин. All rights reserved.
//

#import "Materials.h"


@implementation Materials

@dynamic matName;
@dynamic matWidth;
@dynamic matPrice;
@dynamic created;
@dynamic matId;

@end
