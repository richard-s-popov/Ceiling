//
//  Projects.m
//  Calculator
//
//  Created by Александр Коровкин on 23.09.13.
//  Copyright (c) 2013 Александр Коровкин. All rights reserved.
//

#import "Projects.h"


@implementation Projects

@dynamic projectAdress;
@dynamic projectBypass;
@dynamic projectExplane;
@dynamic projectLuster;
@dynamic projectName;
@dynamic projectSpot;
@dynamic created;

@end
