//
//  SettingsOptionsModel.m
//  Calculator
//
//  Created by Александр Коровкин on 08.07.13.
//  Copyright (c) 2013 Александр Коровкин. All rights reserved.
//

#import "SettingsOptionsModel.h"

@implementation SettingsOptionsModel


//переменные контактов
@synthesize userName;
@synthesize userPhone;
@synthesize userMail;

@synthesize managerName;
@synthesize managerPhone;
@synthesize managerMail;

@synthesize manufactoryPhone;
@synthesize manufactoryMail;


@end
